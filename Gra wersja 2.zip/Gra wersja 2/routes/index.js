const express = require('express');
const router = express.Router();

const PagesController = require('../controllers/PagesController');
const RegisterController = require('../controllers/RegisterController');
const LoginController = require('../controllers/LoginController');
const AdminController = require('../controllers/AdminController');
const GameController = require('../controllers/GameControler')
const NewGameController = require('../controllers/NewGameController')

router.get('/', PagesController.home);
router.post('/Login', LoginController.Login);

router.get('/RegisterPage', PagesController.RegisterPage);
router.post('/Register', RegisterController.Register);

router.get('/Game', PagesController.Game);
router.post('/NewGame', GameController.NewGame)
router.get('/NewGame', PagesController.NewGame)
router.post('/StartNewGame', NewGameController.StartNewGame)
router.get('/StartNew', PagesController.StartNew)

router.get('/AdminPage', PagesController.AdminPage);
router.post('/AddQuestion', AdminController.AddQuestion);
router.post('/deleteUser/:id', AdminController.deleteUser);
router.post('/deleteQuestion/:id', AdminController.deleteQuestion);
router.post('/EditQuestion', AdminController.EditQuestion);
router.post('/UpdateQuestions', AdminController.UpdateQuestions)

module.exports = router;