module.exports = {
    client: 'mysql2',
    connection: {
        user: 'root',
        password: '',
        database: 'gra'
    }
}