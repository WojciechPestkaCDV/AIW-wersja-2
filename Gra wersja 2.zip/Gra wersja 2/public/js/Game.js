
window.addEventListener('beforeunload', function (event) {
    // Wykonaj akcję, gdy użytkownik zamknie stronę
    event.preventDefault(); // Uniknięcie automatycznego zamknięcia okna
    console.log('Użytkownik zamyka stronę');
    // Tu możesz wykonać dodatkowe operacje, np. wysłać żądanie do serwera
})

async function loadJsonDataFromAPI() {
    try {
        const response = await fetch('/api/get-players');
        const jsonData = await response.json();
        return jsonData;
    } catch (error) {
        console.error('Błąd podczas pobierania danych z API:', error);
        return null;
    }
}

async function fetchDataAndUseFromAPI() {
    const loadedData = await loadJsonDataFromAPI();
    console.log('Dane z API:', loadedData);
    const players = loadedData.players;
    const playerscount = loadedData.players.length;
    console.log(`Liczba graczy: ${playerscount}`);

    return { players, playerscount };
}


// Wywołaj funkcję fetchDataAndUseFromAPI()
fetchDataAndUseFromAPI();

async function loadJsonDataFromFile() {
    try {
        const response = await fetch('./jsons/questions.json');
        const jsonData = await response.json();
        return jsonData;
    } catch (error) {
        console.error('Błąd podczas pobierania pliku JSON:', error);
        return null;
    }
}

async function fetchDataAndUseFromFile() {
    const loadedData = await loadJsonDataFromFile();
    console.log('Dane z pliku:', loadedData);
    const questionscount = loadedData.length;
    console.log(`Liczba Pytań ${questionscount}`)
    return { questionscount, loadedData }
}

// Wywołaj funkcję fetchDataAndUseFromFile()
// Wywołaj funkcję fetchDataAndUseFromFile() w bloku async
(async () => {
    const { questionscount, loadedData } = await fetchDataAndUseFromFile();
    const { players, playerscount } = await fetchDataAndUseFromAPI();

    // Funkcja losująca unikalne liczby od 0 do 100
    const randomNumberGenerator = {
        usedNumbers: [],
        getrandomnumber: function (questionscount) {
            const availableNumbers = [];

            for (let i = 0; i < questionscount; i++) {
                if (!this.usedNumbers.includes(i)) {
                    availableNumbers.push(i);
                }
            }

            if (availableNumbers.length === 0) {
                console.log('Nie ma więcej dostępnych unikalnych liczb.');
                return null;
            }

            const randomIndex = Math.floor(Math.random() * availableNumbers.length);
            const randomValue = availableNumbers[randomIndex];
            this.usedNumbers.push(randomValue);

            return randomValue;
        }
    };

    function getRandomIndex(max) {
        return Math.floor(Math.random() * max);
    }

    function swapElements(array, index1, index2) {
        [array[index1], array[index2]] = [array[index2], array[index1]];
    }

    let questionnumber = 0
    let playerIndex = 0;
    element = document.getElementById('nextquestion');
    element.addEventListener('click', function () {
        console.log(players)
        const randomnumber = randomNumberGenerator.getrandomnumber(questionscount);
        console.log(`Wylosowana liczba po kliknięciu: ${randomnumber}`);
        const actualquestion = loadedData[randomnumber].question;
        const actualplayer = players[playerIndex];
        if (actualquestion == 'Zamiana miejsc') {
            const randomIndex1 = playerIndex;
            let randomIndex2 = getRandomIndex(players.length);
            while (randomIndex1 == randomIndex2) {
                randomIndex2 = getRandomIndex(players.length)
            }
            secondplayer = players[randomIndex2]
            swapElements(players, randomIndex1, randomIndex2);
            document.getElementById('actualquestion').innerHTML = `Zamień się miejscem z ${secondplayer}`
            console.log(players)
        } else {
            document.getElementById('actualquestion').innerHTML = actualquestion
        }
        document.getElementById('actualplayer').innerHTML = actualplayer;
        questionnumber++
        document.getElementById('questionnumber').innerHTML = questionnumber
        playerIndex = (playerIndex + 1) % playerscount;
    });
})();

// #actualplayer
// #actualquestion 