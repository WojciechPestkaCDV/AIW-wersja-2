function searchTable(query, tableId) {
    let table = document.querySelector('#' + tableId + ' table');
    let rows = table.querySelectorAll('tbody tr');

    rows.forEach(function (row) {
        let rowData = row.textContent.toLowerCase();
        if (rowData.includes(query.toLowerCase())) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

let adminSearchInput = document.getElementById('usersSearch');
adminSearchInput.addEventListener('input', function () {
    let query = adminSearchInput.value;
    searchTable(query, 'usersTable');
});

let employerSearchInput = document.getElementById('questionsSearch');
employerSearchInput.addEventListener('input', function () {
    let query = employerSearchInput.value;
    searchTable(query, 'questionsTable');
});
