let playerCount = 1;

function addPlayer() {
    const container = document.getElementById('playersContainer');
    const playerInputs = container.getElementsByTagName('input');
    const errorMessage = document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');

    // Sprawdź, czy nie przekroczono limitu graczy (maksymalnie 6)
    if (playerInputs.length >= 6) {
        errorMessage.textContent = 'Osiągnięto limit 6 graczy.';
        errorMessage.style.display = 'block';
        return;
    }

    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = `gracz ${++playerCount}`;
    input.name = `player${playerCount}`;
    input.id = `player${playerCount}`;
    container.appendChild(input);

    // Sprawdź, czy dodano minimum 3 graczy
    if (playerInputs.length >= 3) {
        document.querySelector('button[type="submit"]').disabled = false;
        successMessage.textContent = 'Dodano gracza.';
        successMessage.style.display = 'block';
    } else {
        errorMessage.textContent = 'Dodaj minimum 3 graczy.';
        errorMessage.style.display = 'block';
    }
}

element = document.getElementById('StartGame')
element.addEventListener('click', StartGame);

function StartGame() {
    console.log('StartGame funkcja działa');
    const Players = []
    for (let i = 1; i <= playerCount; i++) {
        const playerValue = document.getElementById(`player${i}`).value;
        console.log(`player${i} tekst to: ${playerValue}`);
        if (playerValue != '') {
            Players.push(playerValue)
        } else {
            break
        }
    }
    console.log(Players)
    fetch('/api/start-game', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ players: Players }),
    })
        .then(response => response.json())
        .then(data => {
            console.log('Odpowiedź z serwera:', data);
            // Możesz tutaj wykonać odpowiednie działania po odebraniu odpowiedzi
        })
        .catch(error => {
            console.error('Błąd podczas przesyłania danych na serwer:', error);
        });
}

// export const Players = StartGame()
