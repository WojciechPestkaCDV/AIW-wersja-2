const bookshelf = require('../config/bookshelf')

const Questions = bookshelf.Model.extend({
    tableName: 'questions',
})

module.exports = Questions;