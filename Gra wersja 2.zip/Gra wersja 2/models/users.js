const bookshelf = require('../config/bookshelf')

const Users = bookshelf.Model.extend({
    tableName: 'users',
})

module.exports = Users;