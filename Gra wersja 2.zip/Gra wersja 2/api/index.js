const express = require('express');
const router = express.Router();

const User = require('../models/users');
const config = require('../controllers/config'); 

router.post('/start-game', async (req, res) => {
    const players = req.body.players;
    try {
        const userId = config.getUserData().id;
        await User.where({ id: userId }).save({ players: JSON.stringify(players) }, { patch: true });

        console.log('Odebrani gracze:', players);
        res.json({ message: 'Dane graczy odebrane na serwerze' });
    } catch (err) {
        console.error('Błąd podczas zapisywania graczy:', err);
        res.status(500).json({ error: 'Błąd podczas zapisywania graczy' });
    }
});


router.get('/get-players', async (req, res) => {
    try {
        const userId = config.getUserData().id;
        const user = await User.where({ id: userId }).fetch();

        if (!user) {
            return res.status(404).json({ error: 'Użytkownik nie istnieje' });
        }

        const players = JSON.parse(user.get('players'));
        res.json({ players: players });
    } catch (err) {
        console.error('Błąd podczas pobierania graczy:', err);
        res.status(500).json({ error: 'Błąd podczas pobierania graczy' });
    }
});


module.exports = router;
