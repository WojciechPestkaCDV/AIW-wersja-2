const bcrypt = require('bcrypt')
const Users = require('../models/users')
const Questions = require('../models/questions')
const fs = require('fs');


exports.StartNewGame = async (req, res, next) => {
    try {
        const QuestionsRecords = await Questions.fetchAll();

        res.render('StartNew', {
            questions: QuestionsRecords.toJSON()
        })
        
    } catch (err) {
        next(err)
    }
}