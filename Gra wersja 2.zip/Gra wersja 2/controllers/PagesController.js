exports.home = (req, res) => {
    res.render('LogPage', {
        formMessage: req.flash('form')
    })
}

exports.RegisterPage = (req, res) => {
    res.render('RegisterPage', {
        formMessage: req.flash('form')
    })
}

exports.AdminPage = (req, res) => {
    res.render('AdminPage', {
        formMessage: req.flash('form')
    })
}

exports.Game = (req, res) => {
    res.render('Game', {
        formMessage: req.flash('form')
    })
}

exports.NewGame = (req, res) => {
    res.render('NewGame', {
        formMessage: req.flash('form')
    })
}

exports.StartNew = (req, res) => {
    res.render('StartNew', {
        formMessage: req.flash('form')
    })
}