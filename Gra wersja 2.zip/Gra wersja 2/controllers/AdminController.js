const Users = require('../models/users')
const Questions = require('../models/questions')
const fs = require('fs');

exports.deleteUser = async (req, res, next) => {
    const { id } = req.params;
    try {
        const user = await Users.where({ id }).fetch();
        if (!user) {
            return res.status(404).send('Użytkownaik nie ustnieje');
        }
        await user.destroy();
        res.status(200).send('<script>window.history.back();</script>')
    } catch(err) {
        next(err);
    }
}

exports.deleteQuestion = async (req, res, next) => {
    console.log('usuwanie pytanka')
    const { id } = req.params;
    try {
        console.log('Usunięcie Pytania')
        const question = await Questions.where({ id }).fetch();
        if (!question) {
            return res.status(404).send('Użytkownaik nie ustnieje');
        }
        await question.destroy();
        res.status(201).send('<script>window.history.back();</script>')
    } catch(err) {
        next(err);
    }
}

exports.AddQuestion = async (req, res, next) => {
    const { question } = req.body;
    try {
        console.log(question)
        const number = parseInt(req.body.number, 10);
        console.log(number);
        const questions = new Questions({
            number: number,
            question: question,
        })
        console.log('przed save')
        await questions.save()
        console.log('po save')
        res.status(200).send('<script>window.history.back();</script>');
    } catch (err) {
        next(err)
    }
}

exports.EditQuestion = async (req, res, next) => {
    const { question } = req.body;
    try {
        console.log('Edycja')
        const number = parseInt(req.body.number, 10);
        const id = parseInt(req.body.id, 10);
        const Question = await Questions.where({ id }).fetch();
        await Question.save({
            number: number,
            question: question,
        })
        res.status(200).send('<script>window.history.back();</script>');
    } catch (err) {
        next(err)
    }
}

exports.UpdateQuestions = async (req, res, next) => {
    try {
        const QuestionsRecords = await Questions.fetchAll();
        const dataToSave = JSON.stringify(QuestionsRecords.toJSON(), null, 2);
        fs.writeFile('./public/jsons/questions.json', dataToSave, (err) => {
            if (err) {
                console.error('Błąd zapisu danych do pliku:', err);
            } else {
                console.log('Dane zostały zapisane do pliku questions.json');
            }
        });
        res.status(200).send('<script>window.history.back();</script>');

    } catch (err) {
        next(err)
    }
}