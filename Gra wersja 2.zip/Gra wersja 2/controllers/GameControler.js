const Users = require('../models/users')
const config = require('./config');

exports.NewGame = async (req, res, next) => {
    try {
        const userData = config.getUserData();
        if (userData) {
            console.log('Użytkownik zalogowany:', userData);
        }
        res.render('NewGame', {
            userData: userData
        })
    } catch (err) {
        next(err)
    }
}