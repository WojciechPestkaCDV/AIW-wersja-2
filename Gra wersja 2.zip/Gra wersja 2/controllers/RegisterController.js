const bcrypt = require('bcrypt')
const User = require('../models/users')

exports.Register = async (req, res, next) => {
    const { name, email, password, repeatpassword } = req.body;
    console.log('próba logowania')

    if (password !== repeatpassword) {
        return res.send('Hasła nie zgadzają się');
    }

    try {
        // Sprawdzenie, czy użytkownik już istnieje w bazie danych
        const existingUser = await User.where({ email }).fetch();

        if (existingUser) {
          return res.send('Użytkownik o podanym adresie email już istnieje');
        }

    } catch (err) {
        const hashedpassword = await bcrypt.hash(password, 10)
        const user = new User({
            name: name,
            email: email,
            password: hashedpassword
        });
        await user.save();

        res.send('Rejestracja zakończona sukcesem. Możesz się teraz zalogować.');
        next(err)
    }
};