
let userData = null;

function setUserData(data) {
    userData = data;
}

function getUserData() {
    return userData;
}

module.exports = {
    setUserData,
    getUserData
};
