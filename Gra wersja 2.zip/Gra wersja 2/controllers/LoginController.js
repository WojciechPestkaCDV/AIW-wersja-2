const bcrypt = require('bcrypt')
const Users = require('../models/users')
const Questions = require('../models/questions')
const fs = require('fs');
const config = require('./config');

exports.Login = async (req, res, next) => {
    console.log('Próba zalogowania')
    const { email, password } = req.body;
    try {
        console.log('Próba zalogowania')
        const User = await Users.where({ email }).fetch();
        console.log('------------------')
        if (!User) {
            return res.status(404).send('Użytkownik nie istnieje')
        }
        const match = await bcrypt.compare(password, User.get('password'))
        if (!match) {
            return res.status(402).send('Nieprawidłowy email lub hasło')
        }
        const UserData = {
            id: User.get('id'),
            name: User.get('name'),
            email: User.get('email'),
            typ: User.get('typ')
        }
        config.setUserData(UserData);
        const UserType = User.get('typ')
        const QuestionsRecords = await Questions.fetchAll();
        const UserRecords = await Users.fetchAll();
        const UserDatas = {
            id: req.session.id,
            name: req.session.name,
            email: req.session.email,
        }
        let additionalDataPath = '../public/jsons/questions.json';
        let additionalData = require(additionalDataPath);
        console.log(additionalData)
        if (UserType == 'admin') {
            console.log('Logowanie Admina')
            res.render('AdminPage', {
                userData: UserData,
                userDatas: UserDatas,
                questions: QuestionsRecords.toJSON(),
                users: UserRecords.toJSON(),
                additionalData: additionalData,
            })
        } else {
            res.render('Game', {
                userData: UserData,
                questions: QuestionsRecords.toJSON()
            })
        }
    } catch (err) {
        next(err)
    }
}